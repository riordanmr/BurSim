// BurSimRet.h 

typedef enum enum_retcode {
  BE_NO_ERROR=0, BE_CANT_OPEN_FILE, 
} BurSimRet;