myint = 3;
SPOMsg("Hi from js");