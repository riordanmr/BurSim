import sys
outfp = open('\\tmp\\PythonTestOut.txt', 'w')
outfp.write('hi there')
outfp.close()
SPOMsg('Message from Python!')