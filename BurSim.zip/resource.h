//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BurSim.rc
//
#define IDS_DESCRIPTION                 1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SAVER_DIALOG                102
#define IDS_SCREENSAVER                 102
#define IDR_MAINFRAME                   128
#define IDC_NULLCURSOR                  129
#define IDD_DIALOG_CONFIG               131
#define IDI_ICON_CONSOLE                132
#define IDC_EDIT_FONT_SAVER_1           1000
#define IDC_SCROLLBAR1                  1002
#define IDC_SCROLLBAR_SPEED             1002
#define IDC_CAP_STYLE                   1003
#define IDC_SCROLLBAR2                  1004
#define IDC_SCROLLBAR_RES               1004
#define IDC_JOIN_STYLE                  1005
#define IDC_PREVIEW                     1006
#define IDC_BUTTON_COLOR                1007
#define IDC_STATIC_GROUP_FONTS          1009
#define IDC_STATIC_DISPLAY_LEFT         1010
#define IDC_STATIC_GROUP_RIGHT          1011
#define IDC_RADIO_LEFT_B                1012
#define IDC_RADIO_LEFT_X                1013
#define IDC_RADIO_RIGHT_B               1014
#define IDC_RADIO_RIGHT_X               1015
#define IDC_RADIO_RIGHT_NONE            1016
#define IDC_STATIC_FONT_SAVER_1         1018
#define IDC_EDIT_FONT_SAVER_2           1019
#define IDC_EDIT_FONT_WINDOWED_1        1020
#define IDC_STATIC_FONT_WINDOWED_1      1021
#define IDC_EDIT_FONT_WINDOWED_2        1022
#define IDC_STATIC__FONT_WINDOWED_2     1023
#define IDC_EDIT_DEBUG                  1024
#define IDC_STATIC_DEBUG                1025
#define IDC_BUTTON_HELP                 1026
#define IDC_RUN_SCRIPT                  1027
#define IDC_EDIT_SECS_REFRESH           1030
#define IDC_CHECK_RUN_DEBUGGER          1031
#define IDC_EDIT_TCP_LISTEN_PORT        1032
#define IDC_STATIC_TCP_LISTEN_PORT      1033
#define IDC_CHECK_SHOW_WELCOME          1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
