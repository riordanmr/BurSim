// Command.h

int ExecuteCommand(CString strCmd, BOOL bFromConsole);