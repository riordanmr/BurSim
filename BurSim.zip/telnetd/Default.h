// Default.h

#define MAXSTATIONS   1000
